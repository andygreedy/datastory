function am4themes_myTheme3(target) {
    if (target instanceof am4core.ColorSet) {
      target.list = [  
        am4core.color("#1E3F66"),
        am4core.color("#0f3460"), 
        am4core.color("#1E3F66"),
        am4core.color("#2E5984"),
        am4core.color("#528AAE"),
        am4core.color("#73A5C6"),
        am4core.color("#91BAD6"),
        am4core.color("#BCD2E8"),
      ];
    }
  }