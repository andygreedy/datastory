am4core.ready(function() {

    // Themes begin
    am4core.useTheme(am4themes_dataviz);
    am4core.useTheme(am4themes_animated);
    // Themes end
    
    // Create map instance
    var chart = am4core.create("topsubsidiesmap", am4maps.MapChart);

    // Set map definition
    chart.geodataSource.url = "https://www.amcharts.com/lib/4/geodata/json/chinaHigh.json"; //Geojson format because we have the polygon boundaries definition 

    // Set projection
    chart.projection = new am4maps.projections.Mercator();

    var title = chart.titles.create();
    title.text = "Number of Students Receiving Subsidies in 2021/22 \n (Until early March 2022)";
    title.align = "center"
    title.fill = '#6c757d'
    title.fontWeight = 600;
    title.fontSize = 18;
    title.marginTop = 10;
    title.marginBottom = 10;
  
  // Create map polygon series
  var polygonSeries = chart.series.push(new am4maps.MapPolygonSeries());
  polygonSeries.exclude = ["AQ"];
  polygonSeries.useGeodata = true;
  polygonSeries.calculateVisualCenter = true;
  polygonSeries.mapPolygons.template.tooltipPosition = "fixed";
  
  // Zoom control
  chart.zoomControl = new am4maps.ZoomControl();

  var homeButton = new am4core.Button();
  homeButton.events.on("hit", function() {
    chart.goHome();
  });

  homeButton.icon = new am4core.Sprite();
  homeButton.padding(7, 5, 7, 5);
  homeButton.width = 30;
  homeButton.icon.path = "M16,8 L14,8 L14,16 L10,16 L10,10 L6,10 L6,16 L2,16 L2,8 L0,8 L8,0 L16,8 Z M16,8";
  homeButton.marginBottom = 10;
  homeButton.parent = chart.zoomControl;
  homeButton.insertBefore(chart.zoomControl.plusButton);

  // Configure series
  var polygonTemplate = polygonSeries.mapPolygons.template;
  //polygonTemplate.fill = am4core.color("#004216");
  polygonTemplate.polygon.fillOpacity = 0.5;
  polygonTemplate.tooltipPosition = "fixed";
  polygonTemplate.interactionsEnabled = false;
  polygonTemplate.propertyFields.interactionsEnabled = "hoverable";
  polygonTemplate.propertyFields.fill = "fill";
  
  polygonSeries.data = [{
    "id":"CN-SH",
    "title": "Shanghai",
    "value":165,
    "pop":165,
    "hoverable": true
  },{
    "id":"CN-SD",
    "title": "Shandong",
    "value": 42,
    "pop":42, 
    "hoverable": true
  },{
    "id":"CN-TJ",
    "title": "Tianjin",
    "value": 21,
    "pop": 21, 
    "hoverable": true,
  },{
    "id":"CN-BJ",
    "title": "Beijing",
    "value":383,
    "pop":383,
    "hoverable": true
  },{
    "id":"CN-SC",
    "title": "Sichuan",
    "value": 59,
    "pop": 59,
    "hoverable": true
  },{
    "id":"CN-GS",
    "title": "Gansu",
    "value":1,
    "pop":1,
    "hoverable": true
  },{
   "id":"CN-JL",
   "title": "Jilin",
   "value":6,
   "pop":6,
   "hoverable": true
 },{
   "id":"CN-JX",
   "title": "Jiangxi",
   "value":9,
   "pop":9,
   "hoverable": true
 },{
   "id":"CN-HA",
   "title": "Henan",
   "value":11,
   "pop":11,
   "hoverable": true
 },{
   "id":"CN-CQ",
   "title": "Chongqing",
   "value":47,
   "pop":47,
   "hoverable": true
 },{
   "id":"CN-ZJ",
   "title": "Zhejiang",
   "value":37,
   "pop":37,
   "hoverable": true
 },{
   "id":"CN-HI",
   "title": "Hainan",
   "value":1,
   "pop":1,
   "hoverable": true
 },{
   "id":"CN-SN",
   "title": "Shaanxi",
   "value":12,
   "pop":12,
   "hoverable": true
 },{
   "id":"CN-HB",
   "title": "Hubei",
   "value":77,
   "pop":77,
   "hoverable": true
 },{
   "id":"CN-HN",
   "title": "Hunan",
   "value":34,
   "pop":34,
   "hoverable": true
 },{
   "id":"CN-YN",
   "title": "Yunnan",
   "value":6,
   "pop":6,
   "hoverable": true
 },{
   "id":"CN-FJ",
   "title": "Fujian",
   "value":570,
   "pop":570,
   "hoverable": true
 },{
   "id":"CN-GX",
   "title": "Guangxi Zhuang",
   "value":29,
   "pop":29,
   "hoverable": true
 },{
   "id":"CN-GD",
   "title": "Guangdong",
   "value":1851,
   "pop":1851,
   "hoverable": true
 },{
   "id":"CN-LN",
   "title": "Liaoning",
   "value":4,
   "pop":4,
   "hoverable": true
 }];

  // Create hover state and set alternative fill color
  var hs = polygonTemplate.states.create("hover");
  hs.properties.fill = am4core.color("#0f3460");

  // Pins
  var imageSeries1 = chart.series.push(new am4maps.MapImageSeries());
  var imageTemplate1 = imageSeries1.mapImages.template;
  imageTemplate1.propertyFields.longitude = "longitude";
  imageTemplate1.propertyFields.latitude = "latitude";
  imageTemplate1.nonScaling = true;
  
  // Creating a pin bullet
  var pin = imageTemplate1.createChild(am4plugins_bullets.PinBullet);
  
  // Configuring pin appearance
  pin.background.fill = am4core.color("#0f3460");
  pin.background.pointerBaseWidth = 1;
  pin.background.pointerLength = 100;
  pin.background.propertyFields.pointerLength = "length";
  pin.background.fillOpacity = 0.5;
  pin.background.radius = 12;
  pin.circle.fill = pin.background.fill;
  pin.circle.fillOpacity = 0.5;
  pin.circle.radius = 7;
  pin.label = new am4core.Label();
  pin.label.text = "{value}";
  pin.label.fill = am4core.color("#fff");

  
  var label = pin.createChild(am4core.Label);
  label.text = "{title}";
  label.fontWeight = "bold";
  label.propertyFields.dy = 35;
  label.propertyFields.dx = "dx";
  label.verticalCenter = "middle";
  label.fill = am4core.color("#0f3460");
  label.adapter.add("dy", function(dy) {
    return (20 + dy) * -1;
  });
  
  // Pin data
  imageSeries1.data = [{
    "title": "Hong Kong",
    "latitude": 22.302711,
    "longitude": 114.177216,
    "length": 40,
    "dx": 10
  }];

   // Add image series
   var imageSeries2 = chart.series.push(new am4maps.MapImageSeries());
   imageSeries2.dataFields.value = "value";
   //imageSeries2.mapImages.template.propertyFields.longitude = "longitude";
   //imageSeries2.mapImages.template.propertyFields.latitude = "latitude";
   imageSeries2.mapImages.template.tooltipText = "{title}: {pop}";
   imageSeries2.mapImages.template.propertyFields.url = "url";
   imageSeries2.mapImages.template.propertyFields.href = "href";

   imageSeries2.tooltip.background.fill = am4core.color("#e94560");
   imageSeries2.tooltip.getFillFromObject = false;
   imageSeries2.tooltip.background.fillOpacity = 0.5;
   imageSeries2.tooltip.background.stroke = am4core.color("#fff");
   imageSeries2.tooltip.label.fill = am4core.color("#fff")

   var circle = imageSeries2.mapImages.template.createChild(am4core.Circle);
   circle.radius = 5;
   circle.fill = am4core.color("#df4e71");
   circle.nonScaling = true;
   circle.applyOnClones = true;
   
   var circle2 = imageSeries2.mapImages.template.createChild(am4core.Circle);
   //circle2.radius = 3;
   circle2.fill = am4core.color("#df4e71");
   
   circle2.events.on("inited", function(event){
     animateBullet(event.target);
   })
   
   
   function animateBullet(circle) {
       var animation = circle.animate([{ property: "scale", from: 1 / chart.zoomLevel, to: 3 / chart.zoomLevel }, { property: "opacity", from: 1, to: 0 }], 2000, am4core.ease.circleOut);
       animation.events.on("animationended", function(event){
         animateBullet(event.target.object);
       })
   }

   imageSeries2.heatRules.push({
    target: circle,
    property: "radius",
    min:2, 
    max:8,
    dataField: "value"
    });
 
   imageSeries2.heatRules.push({
     target: circle2,
     property: "radius",
     min:4, 
     max:10,
     dataField: "value"
   });
   var colorSet = new am4core.ColorSet();
   
   imageSeries2.data = [{
       "id":"CN-SH",
       "title": "Shanghai",
       "value":165,
       "pop":165,
       "hoverable": true
     },{
       "id":"CN-SD",
       "title": "Shandong",
       "value": 42,
       "pop":42, 
       "hoverable": true
     },{
       "id":"CN-TJ",
       "title": "Tianjin",
       "value": 21,
       "pop": 21, 
       "hoverable": true,
     },{
       "id":"CN-BJ",
       "title": "Beijing",
       "value":383,
       "pop":383,
       "hoverable": true
     },{
       "id":"CN-SC",
       "title": "Sichuan",
       "value": 59,
       "pop": 59,
       "hoverable": true
     },{
       "id":"CN-GS",
       "title": "Gansu",
       "value":1,
       "pop":1,
       "hoverable": true
     },{
      "id":"CN-JL",
      "title": "Jilin",
      "value":6,
      "pop":6,
      "hoverable": true
    },{
      "id":"CN-JX",
      "title": "Jiangxi",
      "value":9,
      "pop":9,
      "hoverable": true
    },{
      "id":"CN-JS",
      "title": "Jiangsu",
      "value":90,
      "pop":90,
      "hoverable": true
    },{
      "id":"CN-HA",
      "title": "Henan",
      "value":11,
      "pop":11,
      "hoverable": true
    },{
      "id":"CN-CQ",
      "title": "Chongqing",
      "value":47,
      "pop":47,
      "hoverable": true
    },{
      "id":"CN-ZJ",
      "title": "Zhejiang",
      "value":37,
      "pop":37,
      "hoverable": true
    },{
      "id":"CN-HI",
      "title": "Hainan",
      "value":1,
      "pop":1,
      "hoverable": true
    },{
      "id":"CN-SN",
      "title": "Shaanxi",
      "value":12,
      "pop":12,
      "hoverable": true
    },{
      "id":"CN-HB",
      "title": "Hubei",
      "value":77,
      "pop":77,
      "hoverable": true
    },{
      "id":"CN-HN",
      "title": "Hunan",
      "value":34,
      "pop":34,
      "hoverable": true
    },{
      "id":"CN-YN",
      "title": "Yunnan",
      "value":6,
      "pop":6,
      "hoverable": true
    },{
      "id":"CN-FJ",
      "title": "Fujian",
      "value":570,
      "pop":570,
      "hoverable": true
    },{
      "id":"CN-GX",
      "title": "Guangxi Zhuang",
      "value":29,
      "pop":29,
      "hoverable": true
    },{
      "id":"CN-GD",
      "title": "Guangdong",
      "value":1851,
      "pop":1851,
      "hoverable": true
    },{
      "id":"CN-LN",
      "title": "Liaoning",
      "value":4,
      "pop":4,
      "hoverable": true
    }];

     var imageTemplate2 = imageSeries2.mapImages.template;
    imageTemplate2.nonScaling = false;
    imageTemplate2.applyOnClones = true;

    imageTemplate2.adapter.add("tooltipY", function(tooltipY, target) {
      return -target.children.getIndex(0).radius;
    })

     imageTemplate2.adapter.add("latitude", function(latitude, target) {
      var polygon = polygonSeries.getPolygonById(target.dataItem.dataContext.id);
      if(polygon){
        return polygon.visualLatitude;
       }
       return latitude;
    })
    
    imageTemplate2.adapter.add("longitude", function(longitude, target) {
      var polygon = polygonSeries.getPolygonById(target.dataItem.dataContext.id);
      if(polygon){
        return polygon.visualLongitude;
       }
       return longitude;
    })

  }); // end am4core.ready()