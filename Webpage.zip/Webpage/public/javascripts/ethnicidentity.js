am4core.ready(function() {

    // Themes begin
    am4core.useTheme(am4themes_animated);
    am4core.useTheme(am4themes_myTheme1);
    // Themes end
    
    // Create chart instance
    var chart = am4core.create("ethnicidentity", am4charts.XYChart);
    
    // Add data
    chart.data =[
      {
        "Period": "2022/5/31 - 2022/6/05",
        "Hongkonger": "76.3%",
        "Chinese": "2.20%"
      },
      {
        "Period": "2021/11/29 - 2021/12/03",
        "Hongkonger": "72.5%",
        "Chinese": "5.40%"
      },
      {
        "Period": "2021/6/07 - 2021/6/10",
        "Hongkonger": "67.9%",
        "Chinese": "2.40%"
      },
      {
        "Period": "2020/12/07 - 2020/12/10",
        "Hongkonger": "79.7%",
        "Chinese": "4.00%"
      },
      {
        "Period": "2020/6/01 - 2020/6/04",
        "Hongkonger": "81.1%",
        "Chinese": "3.70%"
      },
      {
        "Period": "2019/12/04 - 2019/12/10",
        "Hongkonger": "81.8%",
        "Chinese": "1.80%"
      },
      {
        "Period": "2019/6/17 - 2019/6/20",
        "Hongkonger": "75.0%",
        "Chinese": "2.70%"
      },
      {
        "Period": "2018/12/03 - 2018/12/06",
        "Hongkonger": "59.2%",
        "Chinese": "4.10%"
      },
      {
        "Period": "2018/6/04 - 2018/6/07",
        "Hongkonger": "70.9%",
        "Chinese": "2.90%"
      },
      {
        "Period": "2017/12/04 - 2017/12/06",
        "Hongkonger": "69.7%",
        "Chinese": "0.30%"
      },
      {
        "Period": "2017/6/13 - 2017/6/15",
        "Hongkonger": "65.0%",
        "Chinese": "3.10%"
      },
      {
        "Period": "2016/12/12 - 2016/12/15",
        "Hongkonger": "62.2%",
        "Chinese": "3.40%"
      },
      {
        "Period": "2016/6/10 - 2016/6/16",
        "Hongkonger": "63.9%",
        "Chinese": "3.80%"
      },
      {
        "Period": "2015/12/03 - 2015/12/07",
        "Hongkonger": "55.6%",
        "Chinese": "7.60%"
      },
      {
        "Period": "2015/6/15 - 2015/6/18",
        "Hongkonger": "62.9%",
        "Chinese": "5.30%"
      },
      {
        "Period": "2014/12/10 - 2014/12/16",
        "Hongkonger": "59.8%",
        "Chinese": "6.50%"
      },
      {
        "Period": "2014/6/06 - 2014/6/12",
        "Hongkonger": "53.1%",
        "Chinese": "3.60%"
      },
      {
        "Period": "2013/12/09 - 2013/12/12",
        "Hongkonger": "59.1%",
        "Chinese": "7.10%"
      },
      {
        "Period": "2013/6/10 - 2013/6/13",
        "Hongkonger": "55.8%",
        "Chinese": "8.70%"
      },
      {
        "Period": "2012/12/14 - 2012/12/17",
        "Hongkonger": "44.0%",
        "Chinese": "5.10%"
      },
      {
        "Period": "2012/6/13 - 2012/6/20",
        "Hongkonger": "69.3%",
        "Chinese": "8.00%"
      },
      {
        "Period": "2011/12/12 - 2011/12/20",
        "Hongkonger": "42.4%",
        "Chinese": "11.80%"
      },
      {
        "Period": "2011/6/21 - 2011/6/22",
        "Hongkonger": "56.8%",
        "Chinese": "11.30%"
      },
      {
        "Period": "2010/12/13 - 2010/12/16",
        "Hongkonger": "45.6%",
        "Chinese": "16.10%"
      },
      {
        "Period": "2010/6/09 - 2010/6/13",
        "Hongkonger": "35.8%",
        "Chinese": "21.60%"
      }
    ];
    //.reverse();
  
    chart.data.forEach(function (o) {
    
      o.Category = "" + o.Category;
      o["Hongkonger"] = o["Hongkonger"] || undefined;
      o["Chinese"] = o["Chinese"] || undefined;
    });
  
    chart.events.on("ready", function () {
      dateAxis.zoom({ start: 0, end: 1 });
    });


    
    // Set input format for the dates
    chart.dateFormatter.inputDateFormat = "yyyy/MM/dd";

    // Create axes
    var dateAxis = chart.xAxes.push(new am4charts.DateAxis());
    dateAxis.renderer.minGridDistance = 60;
    dateAxis.startLocation = 0.5;
    dateAxis.endLocation = 0.5;
    dateAxis.dateFormatter.dateFormat="yyyy/MM/dd";
    dateAxis.min = (new Date(2010,1,01)).getTime();
    dateAxis.max = (new Date(2022,12,31)).getTime();
    dateAxis.baseInterval = {
    timeUnit: "day",
    count: 1
}
    var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
  
    ["Hongkonger", "Chinese"
    ].forEach(function (elem) {

  
    // Create series
    var series = chart.series.push(new am4charts.LineSeries());
    series.dataFields.valueY = elem;
    series.tooltipText ="{Period}\n" + elem + "\n[bold font-size: 20]{valueY}%[/]";
    series.dataFields.dateX = "Period";
    series.strokeWidth = 2;
    series.minBulletDistance = 15;

    // Drop-shaped tooltips
    series.tooltip.background.cornerRadius = 20;
    series.tooltip.background.strokeOpacity = 0;
    series.tooltip.pointerOrientation = "vertical";
    series.tooltip.label.minWidth = 40;
    series.tooltip.label.minHeight = 40;
    series.tooltip.label.textAlign = "left";
    series.tooltip.label.textValign = "middle";
    series.tooltip.background.fillOpacity = 0.5;

    // Make bullets grow on hover
    var bullet = series.bullets.push(new am4charts.CircleBullet());
    bullet.circle.strokeWidth = 2;
    bullet.circle.radius = 4;
    bullet.circle.fill = am4core.color("#fff");

    var bullethover = bullet.states.create("hover");
    bullethover.properties.scale = 1.3;

    // Make a panning cursor
    chart.cursor = new am4charts.XYCursor();
    chart.cursor.maxTooltipDistance = 500;
    chart.cursor.behavior = "panXY";
    chart.cursor.xAxis = valueAxis;
    //chart.cursor.snapToSeries = series;

    series.legendSettings.valueText = elem;
  
    valueAxis.cursorTooltipEnabled = false;
    dateAxis.cursorTooltipEnabled = false;

    chart.zoomOutButton.background.fill = am4core.color("#F8D9D6");
    chart.zoomOutButton.icon.stroke = am4core.color("#fff");
    chart.zoomOutButton.icon.strokeWidth = 2;
    chart.zoomOutButton.background.states.getKey("hover").properties.fill = am4core.color("#f7b6b0");
    chart.zoomOutButton.background.states.getKey("down").properties.fill = am4core.color("#f7b6b0");
    
    dateAxis.start = 0;
    dateAxis.keepSelection = true;
    
    });
    chart.legend = new am4charts.Legend();

    var title = chart.titles.create();
    title.text = 'Ethnic Identity of being "Hongkongers" and "Chinese" \n (18 - 29 Year Old Citizens)';
    title.align = "center";
    title.textAlign = 'middle';
    title.fill = '#6c757d';
    title.paddingBottom = 10;
    title.fontWeight = 600;
    title.fontSize = 20;
    title.marginTop = 10;
    title.marginBottom = 10;
    
    }); // end am4core.ready()