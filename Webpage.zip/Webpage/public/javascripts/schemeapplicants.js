am4core.ready(function() {

  // Themes begin
  am4core.useTheme(am4themes_animated);
  am4core.useTheme(am4themes_myTheme1);
  // Themes end
  
  // Create chart instance
  var chart = am4core.create("schemeapplicants", am4charts.XYChart);
  
  // Add data
  chart.data = [
    {
      "Chartdate": "31/12/2017",
      "Year": "2017/18",
      "Number of Applicants": 3453,
    },
    {
      "Chartdate": "31/12/2018",
      "Year": "2018/19",
      "Number of Applicants": 3403,
    },
    {
      "Chartdate": "31/12/2019",
      "Year": "2019/20",
      "Number of Applicants": 3483,
    },
    {
      "Chartdate": "31/12/2020",
      "Year": "2020/21",
      "Number of Applicants": 4277,
    },
    {
      "Chartdate": "31/12/2021",
      "Year": "2021/22 (till July)",
      "Number of Applicants": 4899,
    }
  ];

    chart.data.forEach(function (o) {
    
      o.Category = "" + o.Category;
      o["Year"] = o["Year"] || undefined;
      o["Number of Applicants"] = o["Number of Applicants"] || undefined;

  });

  chart.events.on("ready", function () {
    dateAxis.zoom({ start: 0, end: 1 });
  });
  
  // Set input format for the dates
  chart.dateFormatter.inputDateFormat = "dd-MM-yyyy";
  
  // Create axes
  var dateAxis = chart.xAxes.push(new am4charts.DateAxis());
  var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
  valueAxis.min = 3000;
  valueAxis.max = 5500;

  [
    "Number of Applicants"
    ].forEach(function (elem) {
  
  
    // Create series
    var series = chart.series.push(new am4charts.LineSeries());
    series.dataFields.valueY = elem;
    series.tooltipText = elem + ": {valueY}"
    series.dataFields.dateX = "Chartdate";
    series.dataFields.realdate = "Year";
    series.strokeWidth = 2;
    series.minBulletDistance = 15;
  
    // Drop-shaped tooltips
    series.tooltip.background.cornerRadius = 20;
    series.tooltip.background.strokeOpacity = 0;
    series.tooltip.pointerOrientation = "vertical";
    series.tooltip.label.minWidth = 40;
    series.tooltip.label.minHeight = 40;
    series.tooltip.label.textAlign = "middle";
    series.tooltip.label.textValign = "middle";
    series.tooltipText = "{realdate}\n[bold font-size: 20]{valueY}[/]";
    series.tooltip.background.fillOpacity = 0.5;
  
    // Make bullets grow on hover
    var bullet = series.bullets.push(new am4charts.CircleBullet());
    bullet.circle.strokeWidth = 2;
    bullet.circle.radius = 4;
    bullet.circle.fill = am4core.color("#fff");
  
    var bullethover = bullet.states.create("hover");
    bullethover.properties.scale = 1.3;
  
    // Make a panning cursor
    chart.cursor = new am4charts.XYCursor();
    chart.cursor.maxTooltipDistance = 500;
    chart.cursor.behavior = "panXY";
    chart.cursor.xAxis = valueAxis;
    //chart.cursor.snapToSeries = series;
  
    series.legendSettings.valueText = elem;
    
    // Create vertical scrollbar and place it before the value axis
    //chart.scrollbarY = new am4core.Scrollbar();
    //chart.scrollbarY.parent = chart.leftAxesContainer;
    //chart.scrollbarY.toBack();
    
    // Create a horizontal scrollbar with previe and place it underneath the date axis
    //chart.scrollbarX.series.push(series);
    //chart.scrollbarX.parent = chart.bottomAxesContainer;
    //chart.scrollbarX = new am4charts.XYChartScrollbar();
    //chart.scrollbarX = new am4core.Scrollbar();
    //chart.scrollbarX.parent = chart.bottomAxesContainer;
  
    valueAxis.cursorTooltipEnabled = false;
    dateAxis.cursorTooltipEnabled = false;
  
    chart.zoomOutButton.background.fill = am4core.color("#df4e71");
    chart.zoomOutButton.icon.stroke = am4core.color("#fff");
    chart.zoomOutButton.icon.strokeWidth = 2;
    chart.zoomOutButton.background.states.getKey("hover").properties.fill = am4core.color("#f7b6b0");
    chart.zoomOutButton.background.states.getKey("down").properties.fill = am4core.color("#f7b6b0");
    
    dateAxis.start = 0;
    dateAxis.keepSelection = true;
    
    });


  var title = chart.titles.create();
  title.text = "Mainland University Study Subsidy Scheme Applicants";
  title.align = "center"
  title.fill = '#6c757d'
  title.paddingBottom = 10;
  title.fontWeight = 600;
  title.fontSize = 20;
  title.marginTop = 10;
  title.marginBottom = 10;
  
  }); // end am4core.ready()