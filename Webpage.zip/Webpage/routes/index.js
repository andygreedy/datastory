var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

/* Handle the Form */
router.post('/form', function (req, res, next) {

  /*var response = {
    header: req.headers,
    body: req.body //server unpackage the info and put it inside req.body
  };*/
  

  console.log("req.body");
  console.log(req.body);

  db.getCollection("contactForm").insert(req.body);

  let result = db.getCollection("contactForm").find();

  /*result.forEach(function (b) {
   b.message.split("\\s+");
  });*/

  res.json(result);

});
var loki = require('lokijs');

var db = new loki('data.json', {
  autoload: true,
  autoloadCallback: databaseInitialize,
  autosave: true,
  autosaveInterval: 4000
});

// implement the autoloadback referenced in loki constructor
function databaseInitialize() {
  var contactForm = db.getCollection("contactForm");
  if (contactForm === null) {
    contactForm = db.addCollection("contactForm");
  }
}

module.exports = router;
